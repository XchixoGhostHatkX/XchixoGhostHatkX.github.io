def __init__():
    import PyBannerGenie
__init__()